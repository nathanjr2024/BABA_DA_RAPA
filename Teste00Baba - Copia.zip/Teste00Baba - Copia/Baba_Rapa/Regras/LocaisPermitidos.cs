namespace Regras
{
    public static class LocaisPermitidos
    {
        public static readonly List<string> Lista = new()
        {
            "Quadra 1",
            "Quadra 2",
            "Quadra 3",
            "Quadra 4",
            "Quadra Coberta"
        };
    }
}
